package com.mazen.langopener;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 32, 32, 32);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        TextView t = new TextView(this);
        t.setText("جرّب الأزرار بالترتيب، أول زر هو الأقرب لتغيير اللغة");
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, 0, 0, 24);
        root.addView(t);

        add(root, "1) شاشة اللغة", new Intent(Settings.ACTION_LOCALE_SETTINGS));
        add(root, "2) اللغة والإدخال (القديمة)", comp("com.android.settings", "com.android.settings.Settings$LanguageAndInputSettingsActivity"));
        add(root, "3) اختيار اللغة المباشر", comp("com.android.settings", "com.android.settings.Settings$LocalePickerActivity"));
        add(root, "4) شاشة اللغة (بديل)", comp("com.android.settings", "com.android.settings.LanguageSettings"));
        add(root, "5) لوحة المفاتيح", new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        add(root, "6) كل الإعدادات", new Intent(Settings.ACTION_SETTINGS));
        add(root, "7) حول الجهاز", new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS));
        add(root, "8) خيارات المطور", new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private Intent comp(String pkg, String cls) {
        Intent i = new Intent();
        i.setComponent(new ComponentName(pkg, cls));
        return i;
    }

    private void add(LinearLayout parent, String label, final Intent intent) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setTextSize(17);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "ما اشتغل على هالشاشة، جرّب الزر اللي بعده", Toast.LENGTH_LONG).show();
                }
            }
        });
        parent.addView(btn);
    }
}
